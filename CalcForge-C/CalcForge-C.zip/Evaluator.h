#include "List.h"

double Evaluate(ArrayInfo* Tokens);