int LengthOf(char* strings);
char IsLetter(char  Char);
char IsNumber(char Char);
char AreNumbers(char* Char, int Length);
ArrayInfo* Join(char** strings, int count);