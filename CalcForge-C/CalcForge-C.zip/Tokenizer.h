#include "List.h"
ArrayInfo* Tokenize(char* strings);